package com.glass.launcher

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.*
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private var drawerOpen by mutableStateOf(false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LauncherUI(drawerOpen, { drawerOpen = it }, this) }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        drawerOpen = false
    }
}

data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap)

fun loadApps(ctx: Context): List<AppItem> {
    val pm = ctx.packageManager
    val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(i, 0)
        .filter { it.activityInfo.packageName != ctx.packageName }
        .map { AppItem(it.loadLabel(pm).toString(), it.activityInfo.packageName, it.loadIcon(pm).toBitmap(160, 160).asImageBitmap()) }
        .distinctBy { it.pkg }
        .sortedBy { it.label.lowercase() }
}

fun setBlur(a: ComponentActivity, radius: Int) {
    if (Build.VERSION.SDK_INT >= 31) {
        a.window.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)
        val lp = a.window.attributes
        lp.blurBehindRadius = radius
        a.window.attributes = lp
    }
}

fun Modifier.glass(radius: Dp = 28.dp): Modifier {
    val shape = RoundedCornerShape(radius)
    return this
        .shadow(12.dp, shape, ambientColor = Color.Black.copy(.25f), spotColor = Color.Black.copy(.35f))
        .clip(shape)
        .background(Brush.linearGradient(listOf(Color.White.copy(.30f), Color.White.copy(.08f))))
        .border(1.dp, Brush.linearGradient(listOf(Color.White.copy(.75f), Color.White.copy(.05f), Color.White.copy(.35f))), shape)
}

@Composable
fun LauncherUI(open: Boolean, setOpen: (Boolean) -> Unit, act: ComponentActivity) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("glass", Context.MODE_PRIVATE) }
    var apps by remember { mutableStateOf<List<AppItem>>(emptyList()) }
    var pins by remember { mutableStateOf<Set<String>?>(prefs.getStringSet("pins", null)?.toSet()) }

    LaunchedEffect(Unit) { apps = withContext(Dispatchers.Default) { loadApps(ctx) } }
    LaunchedEffect(open) { setBlur(act, if (open) 90 else 0) }
    BackHandler(open) { setOpen(false) }

    val p = pins
    val pinned = if (p == null) apps.take(8) else apps.filter { it.pkg in p }
    val pinnedSet = pinned.map { it.pkg }.toSet()

    fun launch(a: AppItem) {
        ctx.packageManager.getLaunchIntentForPackage(a.pkg)?.let { ctx.startActivity(it) }
        setOpen(false)
    }
    fun togglePin(a: AppItem) {
        val cur = pinnedSet.toMutableSet()
        if (!cur.add(a.pkg)) cur.remove(a.pkg)
        pins = cur
        prefs.edit().putStringSet("pins", cur).apply()
    }

    Box(
        Modifier.fillMaxSize().windowInsetsPadding(WindowInsets.systemBars)
            .pointerInput(Unit) {
                var acc = 0f
                detectVerticalDragGestures(
                    onDragStart = { acc = 0f },
                    onDragEnd = { if (acc < -120f) setOpen(true) },
                    onVerticalDrag = { _, d -> acc += d }
                )
            }
    ) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.height(28.dp))
            ClockCard()
            Spacer(Modifier.height(32.dp))
            pinned.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 20.dp)) {
                    row.forEach { app ->
                        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
                            Icon3D(app, 64.dp, { launch(app) }, { togglePin(app) })
                        }
                    }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
        BasicText(
            "swipe up for all apps",
            Modifier.align(Alignment.BottomCenter).padding(bottom = 10.dp),
            style = TextStyle(color = Color.White.copy(.65f), fontSize = 12.sp)
        )
        AnimatedVisibility(
            open,
            enter = fadeIn() + slideInVertically { it / 3 },
            exit = fadeOut() + slideOutVertically { it / 3 }
        ) {
            Drawer(apps, { launch(it) }, { togglePin(it) })
        }
    }
}

@Composable
fun ClockCard() {
    var now by remember { mutableStateOf(Date()) }
    LaunchedEffect(Unit) { while (true) { now = Date(); delay(10_000) } }
    Column(Modifier.glass(32.dp).padding(horizontal = 32.dp, vertical = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        BasicText(
            SimpleDateFormat("HH:mm", Locale.getDefault()).format(now),
            style = TextStyle(color = Color.White, fontSize = 64.sp, fontWeight = FontWeight.Light)
        )
        BasicText(
            SimpleDateFormat("EEEE, d MMMM", Locale.getDefault()).format(now),
            style = TextStyle(color = Color.White.copy(.85f), fontSize = 15.sp)
        )
    }
}

@Composable
fun Drawer(apps: List<AppItem>, onLaunch: (AppItem) -> Unit, onPin: (AppItem) -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(q, apps) { if (q.isBlank()) apps else apps.filter { it.label.contains(q, true) } }
    Column(Modifier.fillMaxSize().background(Color.Black.copy(.28f)).padding(horizontal = 16.dp)) {
        Spacer(Modifier.height(12.dp))
        BasicTextField(
            q, { q = it },
            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
            cursorBrush = SolidColor(Color.White),
            singleLine = true,
            modifier = Modifier.fillMaxWidth().glass(24.dp).padding(horizontal = 18.dp, vertical = 14.dp),
            decorationBox = { inner ->
                Box {
                    if (q.isEmpty()) BasicText("Search apps", style = TextStyle(color = Color.White.copy(.6f), fontSize = 16.sp))
                    inner()
                }
            }
        )
        Spacer(Modifier.height(16.dp))
        LazyVerticalGrid(
            GridCells.Fixed(4),
            contentPadding = PaddingValues(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            items(list, key = { it.pkg }) { app ->
                Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Icon3D(app, 60.dp, { onLaunch(app) }, { onPin(app) })
                }
            }
        }
    }
}

@Composable
fun Icon3D(app: AppItem, size: Dp, onClick: () -> Unit, onLong: () -> Unit) {
    var pressed by remember { mutableStateOf(false) }
    var tilt by remember { mutableStateOf(Offset.Zero) }
    var box by remember { mutableStateOf(IntSize(1, 1)) }
    val s by animateFloatAsState(if (pressed) 0.9f else 1f, label = "s")
    val rx by animateFloatAsState(tilt.y, label = "rx")
    val ry by animateFloatAsState(tilt.x, label = "ry")
    val shape = RoundedCornerShape(size * 0.3f)

    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.size(size)
                .graphicsLayer { scaleX = s; scaleY = s; rotationX = rx; rotationY = ry; cameraDistance = 14f * density }
                .onSizeChanged { box = IntSize(it.width.coerceAtLeast(1), it.height.coerceAtLeast(1)) }
                .pointerInput(Unit) {
                    detectTapGestures(
                        onPress = { o ->
                            pressed = true
                            tilt = Offset((o.x / box.width - .5f) * 40f, -(o.y / box.height - .5f) * 40f)
                            tryAwaitRelease()
                            pressed = false
                            tilt = Offset.Zero
                        },
                        onTap = { onClick() },
                        onLongPress = { onLong() }
                    )
                }
        ) {
            // thickness (3D edge)
            Box(Modifier.fillMaxSize().offset(y = 4.dp).clip(shape).background(Color.Black.copy(.35f)))
            // glass body
            Box(
                Modifier.fillMaxSize()
                    .shadow(14.dp, shape, ambientColor = Color.Black.copy(.3f), spotColor = Color.Black.copy(.45f))
                    .clip(shape)
                    .background(Brush.verticalGradient(listOf(Color(0xFF8CA0C8).copy(.55f), Color(0xFF1B2238).copy(.78f))))
                    .border(1.2.dp, Brush.verticalGradient(listOf(Color.White.copy(.85f), Color.White.copy(.05f))), shape)
            )
            // icon with parallax
            Image(
                app.icon, null,
                Modifier.align(Alignment.Center).fillMaxSize(0.66f)
                    .graphicsLayer { translationX = -ry * 0.8f; translationY = rx * 0.8f }
            )
            // specular highlight
            Box(
                Modifier.fillMaxSize().clip(shape)
                    .background(Brush.verticalGradient(0f to Color.White.copy(.40f), .45f to Color.Transparent, 1f to Color.Transparent))
            )
        }
        Spacer(Modifier.height(6.dp))
        BasicText(
            app.label,
            Modifier.width(size + 12.dp),
            style = TextStyle(
                color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center,
                shadow = Shadow(Color.Black.copy(.6f), blurRadius = 6f)
            ),
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}
